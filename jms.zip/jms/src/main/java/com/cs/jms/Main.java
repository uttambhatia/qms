package com.cs.jms;
import org.springframework.boot.SpringApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.jms.core.JmsTemplate;
import java.util.Date;

public class Main {

	//https://howtodoinjava.com/spring-boot/spring-boot-jmstemplate-activemq/#demo
	//
	public static void main(String[] args) {
		 // Launch the application
        ConfigurableApplicationContext context = SpringApplication.run(JMSApplication.class, args);
 
        //Get JMS template bean reference
        JmsTemplate jmsTemplate = context.getBean(JmsTemplate.class);
 
        // Send a message
        System.out.println("Sending a message.");
        jmsTemplate.convertAndSend("jms.message.endpoint", new Message(1001L, "test body", new Date()));

	}

}
