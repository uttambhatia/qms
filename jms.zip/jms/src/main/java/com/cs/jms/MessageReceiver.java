package com.cs.jms;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

@Component("receiver")
public class MessageReceiver {
 
    @JmsListener(destination = "jms.message.endpoint")
    public void receiveMessage(Message msg)
    {
        System.out.println("Received " + msg );
    }
}