package com.cs.jms;

/**
 * Created by rohan on 2017/10/18.
 */
import javax.jms.*;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;
import org.springframework.stereotype.Component;

@Component(value = "topicMsgSender")
public class TopicMsgSender {

    private JmsTemplate jmsTemplate;

    public void sendMessage(final String message, final String CorrId) {

        jmsTemplate.send(new MessageCreator() {

                @Override
            public javax.jms.Message createMessage(Session session) throws JMSException {
                TextMessage msg = session.createTextMessage(message);
                msg.setJMSCorrelationID(CorrId);
                return msg;
            }
        });
    }

    public JmsTemplate getJmsTemplate() {
        return jmsTemplate;
    }

    public void setJmsTemplate(JmsTemplate jmsTemplate) {
        this.jmsTemplate = jmsTemplate;
    }
}