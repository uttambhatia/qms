package com.cs.jms;

import com.cs.jms.QueueMsgSender;
//import com.cs.jms.TopicMsgSender;
import org.springframework.context.support.GenericXmlApplicationContext;
import java.util.UUID;

public class TestJmsSender {

	public static void main(String[] args) {
        GenericXmlApplicationContext ctx = new GenericXmlApplicationContext();

        ctx.load("classpath:Jms-conf.xml");
        ctx.refresh();

        try {
            QueueMsgSender queueMsgSender = ctx.getBean("queueMsgSender", QueueMsgSender.class);
            queueMsgSender.sendMessage("Queue msg 1", UUID.randomUUID().toString());

          /*  TopicMsgSender topicMsgSender = ctx.getBean("topicMsgSender", TopicMsgSender.class);
            topicMsgSender.sendMessage("Queue msg2", UUID.randomUUID().toString());*/
        } catch (Exception ae) {
            System.out.print("Error " + ae);
        }
    }
	
}
